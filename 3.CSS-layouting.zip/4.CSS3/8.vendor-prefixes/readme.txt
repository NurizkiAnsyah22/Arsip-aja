kunjungi https://shouldiprefix.com untuk liat property apa saja yang harus pakai vendor-prefixs
caniuse.com ( lebih lemgkap)

pleeease.io/play/ ( lebih keren menggunakan sintax css)
